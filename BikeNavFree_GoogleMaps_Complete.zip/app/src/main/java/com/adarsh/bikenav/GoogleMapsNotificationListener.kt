package com.adarsh.bikenav

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class GoogleMapsNotificationListener : NotificationListenerService() {

    companion object {
        private const val GOOGLE_MAPS_PACKAGE = "com.google.android.apps.maps"
        private var lastMessage = ""

        fun isGoogleMapsNotification(sbn: StatusBarNotification): Boolean =
            sbn.packageName == GOOGLE_MAPS_PACKAGE
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        BluetoothManager.initialize(applicationContext)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!isGoogleMapsNotification(sbn)) return

        val extras = sbn.notification.extras

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString(" ")
            .orEmpty()

        val combined = listOf(title, text, bigText, lines)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" ")

        if (combined.isBlank()) return

        val data = parseNavigation(combined)

        NavigationDataStore.update(data)

        if (BluetoothManager.isConnected()) {
            BluetoothManager.send(
                "${data.direction},${data.distance},${data.road},--,--"
            )
        }
    }

    private fun parseNavigation(raw: String): NavigationData {
        val clean = raw.replace(Regex("\\s+"), " ").trim()
        val lower = clean.lowercase(Locale.US)

        val direction = detectDirection(lower)
        val distance = detectDistance(clean)
        val road = detectRoad(clean)

        val message = "$direction,$distance,$road,--,--"

        if (message != lastMessage) {
            lastMessage = message
        }

        return NavigationData(
            direction = direction,
            distance = distance,
            road = road,
            raw = clean
        )
    }

    private fun detectDirection(text: String): String {
        return when {
            Regex("""\bu[\s-]?turn\b|\bmake a u\b""").containsMatchIn(text) ->
                "UTURN"

            Regex("""\bturn\s+left\b|\bkeep\s+left\b|\bslight\s+left\b|\bbear\s+left\b""")
                .containsMatchIn(text) ->
                "LEFT"

            Regex("""\bturn\s+right\b|\bkeep\s+right\b|\bslight\s+right\b|\bbear\s+right\b""")
                .containsMatchIn(text) ->
                "RIGHT"

            else -> "STRAIGHT"
        }
    }

    private fun detectDistance(text: String): String {
        val pattern = Regex(
            """(?i)\b(\d+(?:[.,]\d+)?)\s*(m|meter|meters|km|kilometer|kilometers|mi|mile|miles)\b"""
        )

        val match = pattern.find(text) ?: return "--"

        val number = match.groupValues[1].replace(',', '.')
        val unit = match.groupValues[2].lowercase(Locale.US)

        return when {
            unit.startsWith("km") || unit.startsWith("kilometer") -> "$number km"
            unit.startsWith("mi") || unit.startsWith("mile") -> "$number mi"
            else -> "$number m"
        }
    }

    private fun detectRoad(text: String): String {
        val patterns = listOf(
            Regex("""(?i)\b(?:onto|on|toward|towards)\s+([^,.]+)"""),
            Regex("""(?i)\b(?:take|enter)\s+([^,.]+)""")
        )

        for (pattern in patterns) {
            val match = pattern.find(text) ?: continue
            var road = match.groupValues[1].trim()

            road = road.replace(
                Regex("""(?i)\b(?:for|after|in)\s+\d+.*$"""),
                ""
            ).trim()

            if (road.isNotBlank()) {
                return if (road.length > 24) road.take(24) else road
            }
        }

        return "Google Maps"
    }
}
