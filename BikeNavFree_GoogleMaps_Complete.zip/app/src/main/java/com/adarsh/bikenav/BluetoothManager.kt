package com.adarsh.bikenav

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.util.UUID

object BluetoothManager {
    const val DEVICE_NAME = "BikeNav-ESP32"

    private val SPP_UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var socket: BluetoothSocket? = null
    private var appContext: Context? = null

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }

    private fun hasPermission(): Boolean {
        val context = appContext ?: return false
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S) return true

        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun connect(): Boolean {
        if (!hasPermission()) return false

        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return false
        if (!adapter.isEnabled) return false

        val device: BluetoothDevice? =
            adapter.bondedDevices.firstOrNull { it.name == DEVICE_NAME }

        if (device == null) return false

        return try {
            socket?.close()
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            adapter.cancelDiscovery()
            socket?.connect()
            socket?.isConnected == true
        } catch (_: Exception) {
            try { socket?.close() } catch (_: Exception) {}
            socket = null
            false
        }
    }

    fun isConnected(): Boolean =
        try { socket?.isConnected == true } catch (_: Exception) { false }

    fun send(message: String): Boolean {
        return try {
            val s = socket ?: return false
            if (!s.isConnected) return false
            s.outputStream.write((message.trim() + "\n").toByteArray(Charsets.UTF_8))
            s.outputStream.flush()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }
}
