package com.adarsh.bikenav

data class NavigationData(
    val direction: String,
    val distance: String,
    val road: String,
    val raw: String
)

object NavigationDataStore {
    @Volatile
    var latest: NavigationData? = null
        private set

    private val listeners = mutableSetOf<(NavigationData) -> Unit>()

    @Synchronized
    fun update(data: NavigationData) {
        latest = data
        listeners.toList().forEach { listener ->
            try { listener(data) } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun addListener(listener: (NavigationData) -> Unit) {
        listeners.add(listener)
        latest?.let {
            try { listener(it) } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun removeListener(listener: (NavigationData) -> Unit) {
        listeners.remove(listener)
    }
}
