package com.adarsh.bikenav

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.app.NotificationManager

class MainActivity : AppCompatActivity() {

    private lateinit var txtStatus: TextView
    private lateinit var txtInstruction: TextView
    private lateinit var txtRaw: TextView

    private val navigationListener: (NavigationData) -> Unit = { data ->
        runOnUiThread {
            txtInstruction.text =
                "${data.direction}  ${data.distance}\n${data.road}"
            txtRaw.text = "Raw notification: ${data.raw}"
        }
    }

    private val bluetoothPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {
            connectEsp32()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txtStatus)
        txtInstruction = findViewById(R.id.txtInstruction)
        txtRaw = findViewById(R.id.txtRaw)

        BluetoothManager.initialize(applicationContext)

        findViewById<Button>(R.id.btnNotificationAccess).setOnClickListener {
            openNotificationAccessSettings()
        }

        findViewById<Button>(R.id.btnBluetooth).setOnClickListener {
            requestBluetoothPermission()
        }

        findViewById<Button>(R.id.btnOpenMaps).setOnClickListener {
            openGoogleMaps()
        }
    }

    override fun onStart() {
        super.onStart()
        NavigationDataStore.addListener(navigationListener)
    }

    override fun onStop() {
        NavigationDataStore.removeListener(navigationListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun openNotificationAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (_: Exception) {
            toast("Cannot open notification access settings")
        }
    }

    private fun requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val connectGranted =
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) == PackageManager.PERMISSION_GRANTED

            val scanGranted =
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_SCAN
                ) == PackageManager.PERMISSION_GRANTED

            if (!connectGranted || !scanGranted) {
                bluetoothPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
                return
            }
        }

        connectEsp32()
    }

    private fun connectEsp32() {
        txtStatus.text = "Connecting to BikeNav-ESP32..."

        Thread {
            val connected = BluetoothManager.connect()

            runOnUiThread {
                if (connected) {
                    txtStatus.text = "ESP32 connected"
                    toast("ESP32 connected")
                } else {
                    txtStatus.text = "ESP32 connection failed"
                    toast("Pair ESP32 as BikeNav-ESP32 first")
                }
            }
        }.start()
    }

    private fun openGoogleMaps() {
        try {
            val intent =
                packageManager.getLaunchIntentForPackage(
                    "com.google.android.apps.maps"
                )

            if (intent != null) {
                startActivity(intent)
            } else {
                toast("Google Maps is not installed")
            }
        } catch (_: Exception) {
            toast("Unable to open Google Maps")
        }
    }

    private fun updateStatus() {
        if (isNotificationListenerEnabled()) {
            txtStatus.text = if (BluetoothManager.isConnected()) {
                "Google Maps access enabled • ESP32 connected"
            } else {
                "Google Maps access enabled • ESP32 not connected"
            }
        } else {
            txtStatus.text = "Enable Google Maps notification access"
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val component = ComponentName(
            this,
            GoogleMapsNotificationListener::class.java
        )

        val manager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        return manager.isNotificationListenerAccessGranted(component)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
