#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "BluetoothSerial.h"

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDRESS 0x3C

#define SDA_PIN 21
#define SCL_PIN 22

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  OLED_RESET
);

BluetoothSerial SerialBT;

String direction = "STRAIGHT";
String turnDistance = "--";
String roadName = "Waiting...";
String remainingDistance = "--";
String eta = "--";

void drawArrow(const String &dir) {
  display.fillRect(0, 0, 42, 38, SSD1306_BLACK);

  if (dir == "RIGHT") {
    display.drawLine(8,20,30,20,SSD1306_WHITE);
    display.drawLine(30,20,21,11,SSD1306_WHITE);
    display.drawLine(30,20,21,29,SSD1306_WHITE);
  } else if (dir == "LEFT") {
    display.drawLine(10,20,32,20,SSD1306_WHITE);
    display.drawLine(10,20,19,11,SSD1306_WHITE);
    display.drawLine(10,20,19,29,SSD1306_WHITE);
  } else if (dir == "UTURN") {
    display.drawCircle(20,20,10,SSD1306_WHITE);
    display.fillRect(10,20,21,12,SSD1306_BLACK);
    display.drawLine(10,20,10,10,SSD1306_WHITE);
    display.drawLine(10,10,20,10,SSD1306_WHITE);
    display.drawLine(20,10,15,5,SSD1306_WHITE);
    display.drawLine(20,10,15,15,SSD1306_WHITE);
  } else {
    display.drawLine(20,30,20,8,SSD1306_WHITE);
    display.drawLine(20,8,11,17,SSD1306_WHITE);
    display.drawLine(20,8,29,17,SSD1306_WHITE);
  }
}

void updateDisplay() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  drawArrow(direction);

  display.setTextSize(1);
  display.setCursor(45,0);
  display.print(direction);

  display.setTextSize(2);
  display.setCursor(45,12);
  display.print(turnDistance);

  display.setTextSize(1);
  display.setCursor(0,40);

  String road = roadName;
  if (road.length() > 21) {
    road = road.substring(0,21);
  }
  display.print(road);

  display.setCursor(0,52);
  display.print(remainingDistance);

  display.setCursor(82,52);
  display.print(eta);

  display.display();
}

void parseNavigationData(String data) {
  data.trim();

  Serial.print("Received: ");
  Serial.println(data);

  int p1 = data.indexOf(',');
  int p2 = data.indexOf(',', p1 + 1);
  int p3 = data.indexOf(',', p2 + 1);
  int p4 = data.indexOf(',', p3 + 1);

  if (p1 == -1 || p2 == -1 || p3 == -1 || p4 == -1) {
    return;
  }

  direction = data.substring(0, p1);
  turnDistance = data.substring(p1 + 1, p2);
  roadName = data.substring(p2 + 1, p3);
  remainingDistance = data.substring(p3 + 1, p4);
  eta = data.substring(p4 + 1);

  direction.trim();
  turnDistance.trim();
  roadName.trim();
  remainingDistance.trim();
  eta.trim();

  direction.toUpperCase();

  updateDisplay();
}

void setup() {
  Serial.begin(115200);

  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
    Serial.println("OLED NOT FOUND!");
    while (true) {
      delay(1000);
    }
  }

  SerialBT.begin("BikeNav-ESP32");

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  display.setCursor(10,10);
  display.println("BIKENAV");

  display.setCursor(10,25);
  display.println("Waiting...");

  display.setCursor(10,40);
  display.println("Bluetooth");

  display.display();
}

void loop() {
  if (SerialBT.available()) {
    String data = SerialBT.readStringUntil('\n');
    parseNavigationData(data);
  }

  delay(10);
}
