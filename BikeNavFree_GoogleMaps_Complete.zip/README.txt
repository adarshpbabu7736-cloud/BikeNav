BIKENAV FREE - GOOGLE MAPS COMPANION
======================================

Purpose
-------
Google Maps remains the navigation app on the phone.
BikeNav Free reads Google Maps navigation notifications and sends
a simplified instruction to an ESP32 over Bluetooth Classic SPP.

PHONE
-----
Google Maps
    |
    v
Google Maps notification
    |
    v
BikeNav Google Maps Reader
    |
    v
Bluetooth Classic SPP
    |
    v
ESP32
    |
    v
0.96 inch I2C OLED

ANDROID PROJECT
---------------
Package:
com.adarsh.bikenav

Gradle:
AGP 8.9.1
Gradle 8.11.1
Kotlin 2.1.20
compileSdk 35
minSdk 24

IMPORTANT
---------
The Gradle wrapper is configured for the user's existing local file:

C:/Users/adars/Downloads/gradle-8.11.1-bin.zip

If the ZIP is in another location, edit:
gradle/wrapper/gradle-wrapper.properties

BLUETOOTH
---------
First upload the ESP32 sketch in:
ESP32/BikeNav_ESP32.ino

ESP32 Bluetooth name:
BikeNav-ESP32

Pair it from Android Bluetooth settings.

Then open BikeNav Free and tap:
1. Enable Google Maps Access
2. Connect ESP32
3. Open Google Maps

GOOGLE MAPS ACCESS
------------------
Android Settings -> Notification access -> BikeNav Free -> Allow

LIMITATION
----------
This project does NOT use a Google Maps Platform Navigation SDK.
It does not require a Google Maps API key or billing account.

It reads notifications posted by the Google Maps Android app.
Google Maps/Android may change the notification text or the information
available in it. Therefore the parser cannot guarantee every turn,
road name, ETA, or route distance on every phone/version.

The app sends:
DIRECTION,DISTANCE,ROAD,--,--

Example:
RIGHT,200 m,MG Road,--,--

OLED WIRING
-----------
OLED VCC -> ESP32 3.3V
OLED GND -> ESP32 GND
OLED SDA -> ESP32 GPIO 21
OLED SCK -> ESP32 GPIO 22

BIKE POWER
----------
Do NOT connect bike 12V directly to ESP32.

Recommended:
Bike switched 12V -> 1A fuse -> 12V-to-5V buck converter -> ESP32

The OLED can remain powered from the ESP32 3.3V rail if the module is
designed for 3.3V operation.

TEST
----
Before installing on the bike:
1. Pair ESP32.
2. Enable notification access.
3. Connect ESP32.
4. Start Google Maps navigation.
5. Watch the BikeNav app for the raw notification.
6. Check the OLED.

If Google Maps does not expose useful navigation text in its notification
on the phone, this notification-based approach cannot guarantee full
navigation data. A different integration would then be required.
