// Use the ESP32 program you already tested with the SH1106 OLED.
// Bluetooth device name must be: ESP32_Bike_Nav
// Receive packets: MAIN|DISTANCE|NEXT\n
