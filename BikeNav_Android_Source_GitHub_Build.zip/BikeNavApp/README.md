# BikeNav Android App

Google Maps companion app for ESP32_Bike_Nav.

Flow: Google Maps navigation notification -> BikeNav -> Bluetooth Classic SPP -> ESP32 -> 0.96in SH1106 OLED.

Bluetooth device name: `ESP32_Bike_Nav`
SPP UUID: `00001101-0000-1000-8000-00805F9B34FB`
Packet format: `MAIN|DISTANCE|NEXT\n`

Supported main values: STRAIGHT, LEFT, RIGHT, SLIGHT_LEFT, SLIGHT_RIGHT, UTURN.

## Build without Android Studio
Push this project to GitHub. The included `.github/workflows/build-apk.yml` builds `app-debug.apk` with Gradle 8.13 and uploads it as an Actions artifact.

## Use
1. Install APK.
2. Pair `ESP32_Bike_Nav` in Android Bluetooth settings.
3. In BikeNav, tap Connect ESP32.
4. Enable Google Maps notification access.
5. Open Google Maps and start driving navigation.
6. Use the test buttons first to verify Bluetooth/OLED.

Google Maps notification content varies by Android/device/Maps version; this is a companion/prototype approach, not an official Google Maps turn-by-turn API.
