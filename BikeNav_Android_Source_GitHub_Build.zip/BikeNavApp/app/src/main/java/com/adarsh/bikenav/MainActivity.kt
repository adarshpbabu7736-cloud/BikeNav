package com.adarsh.bikenav

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var instruction: TextView
    private lateinit var raw: TextView

    private val listener: (NavData) -> Unit = { d -> runOnUiThread { instruction.text = "${d.main}\n${d.distance}\nNEXT: ${d.next}"; raw.text = "Raw: ${d.raw}" } }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { connect() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.txtStatus); instruction = findViewById(R.id.txtInstruction); raw = findViewById(R.id.txtRaw)
        BluetoothManager.initialize(applicationContext)
        findViewById<Button>(R.id.btnBluetooth).setOnClickListener { requestBluetooth() }
        findViewById<Button>(R.id.btnNotificationAccess).setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        findViewById<Button>(R.id.btnOpenMaps).setOnClickListener { packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")?.let(::startActivity) ?: toast("Google Maps not installed") }
        val tests = listOf(
            R.id.btnStraight to "STRAIGHT|70m|RIGHT\n", R.id.btnRight to "RIGHT|200m|STRAIGHT\n", R.id.btnLeft to "LEFT|300m|RIGHT\n",
            R.id.btnSlightRight to "SLIGHT_RIGHT|150m|STRAIGHT\n", R.id.btnSlightLeft to "SLIGHT_LEFT|150m|RIGHT\n", R.id.btnUturn to "UTURN|300m|STRAIGHT\n"
        )
        tests.forEach { (id, packet) -> findViewById<Button>(id).setOnClickListener { if (!BluetoothManager.send(packet)) toast("Connect ESP32 first") else toast("Sent: ${packet.trim()}") } }
    }
    override fun onStart() { super.onStart(); NavigationDataStore.addListener(listener) }
    override fun onStop() { NavigationDataStore.removeListener(listener); super.onStop() }
    override fun onResume() { super.onResume(); updateStatus() }

    private fun requestBluetooth() {
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) { permissionLauncher.launch(needed.toTypedArray()); return }
        }
        connect()
    }
    private fun connect() {
        status.text = "Connecting to ESP32_Bike_Nav..."
        Thread {
            val ok = BluetoothManager.connect()
            runOnUiThread { status.text = if (ok) "ESP32_Bike_Nav connected" else "Connection failed — pair ESP32_Bike_Nav in Android Bluetooth settings first" }
        }.start()
    }
    private fun updateStatus() {
        val enabled = (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).isNotificationListenerAccessGranted(ComponentName(this, GoogleMapsNotificationListener::class.java))
        status.text = if (enabled) "Google Maps access enabled • ${if (BluetoothManager.isConnected()) "ESP32 connected" else "ESP32 not connected"}" else "Enable Google Maps notification access"
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
