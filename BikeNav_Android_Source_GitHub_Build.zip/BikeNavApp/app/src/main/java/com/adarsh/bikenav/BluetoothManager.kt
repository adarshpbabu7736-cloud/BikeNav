package com.adarsh.bikenav

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

object BluetoothManager {
    private const val DEVICE_NAME = "ESP32_Bike_Nav"
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null

    fun initialize(context: Context) { adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter }
    fun isConnected(): Boolean = socket?.isConnected == true && output != null

    @Synchronized fun connect(): Boolean {
        val a = adapter ?: return false
        if (android.os.Build.VERSION.SDK_INT >= 31 && !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) return false
        return try {
            val device = a.bondedDevices.firstOrNull { it.name == DEVICE_NAME } ?: return false
            socket?.close()
            val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
            a.cancelDiscovery()
            s.connect()
            socket = s
            output = s.outputStream
            true
        } catch (_: Exception) {
            try { socket?.close() } catch (_: Exception) {}
            socket = null; output = null
            false
        }
    }

    @Synchronized fun send(packet: String): Boolean {
        return try { output?.write(packet.toByteArray(Charsets.UTF_8)); output?.flush(); true } catch (_: Exception) { false }
    }

    private fun hasPermission(permission: String): Boolean {
        return BikeNavHolder.context?.let { ContextCompat.checkSelfPermission(it, permission) == PackageManager.PERMISSION_GRANTED } == true
    }
}

