package com.adarsh.bikenav

import android.app.Application

class BikeNavApp : Application() {
    override fun onCreate() {
        super.onCreate()
        BikeNavHolder.context = applicationContext
        BluetoothManager.initialize(applicationContext)
    }
}

internal object BikeNavHolder { var context: android.content.Context? = null }
