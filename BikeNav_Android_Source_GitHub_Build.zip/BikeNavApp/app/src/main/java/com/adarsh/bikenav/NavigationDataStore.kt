package com.adarsh.bikenav

object NavigationDataStore {
    private val listeners = mutableSetOf<(NavData) -> Unit>()
    @Volatile var last: NavData = NavData("STRAIGHT", "--", "STRAIGHT")

    @Synchronized fun addListener(listener: (NavData) -> Unit) { listeners.add(listener); listener(last) }
    @Synchronized fun removeListener(listener: (NavData) -> Unit) { listeners.remove(listener) }
    @Synchronized fun update(data: NavData) { last = data; listeners.toList().forEach { it(data) } }
}
