package com.adarsh.bikenav

data class NavData(val main: String, val distance: String, val next: String, val raw: String = "") {
    fun packet(): String = "$main|$distance|$next\n"
}
