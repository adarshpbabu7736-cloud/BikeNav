package com.adarsh.bikenav

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class GoogleMapsNotificationListener : NotificationListenerService() {
    companion object { private const val MAPS = "com.google.android.apps.maps" }

    override fun onListenerConnected() { BluetoothManager.initialize(applicationContext) }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != MAPS) return
        val e = sbn.notification.extras
        val parts = listOf(
            e.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            e.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" ")
        ).filterNotNull().filter { it.isNotBlank() }.distinct()
        if (parts.isEmpty()) return
        val raw = parts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
        val data = parse(raw)
        NavigationDataStore.update(data)
        BluetoothManager.send(data.packet())
    }

    private fun parse(raw: String): NavData {
        val t = raw.lowercase(Locale.US)
        val main = when {
            Regex("\\bu[ -]?turn\\b|\\bmake a u[- ]?turn\\b").containsMatchIn(t) -> "UTURN"
            Regex("\\bslight(?:ly)?\\s+left\\b|\\bkeep\\s+left\\b|\\bbear\\s+left\\b").containsMatchIn(t) -> "SLIGHT_LEFT"
            Regex("\\bslight(?:ly)?\\s+right\\b|\\bkeep\\s+right\\b|\\bbear\\s+right\\b").containsMatchIn(t) -> "SLIGHT_RIGHT"
            Regex("\\bturn\\s+left\\b|\\bturn\\s+to\\s+the\\s+left\\b").containsMatchIn(t) -> "LEFT"
            Regex("\\bturn\\s+right\\b|\\bturn\\s+to\\s+the\\s+right\\b").containsMatchIn(t) -> "RIGHT"
            Regex("\\bcontinue\\b|\\bstraight\\b|\\bgo straight\\b").containsMatchIn(t) -> "STRAIGHT"
            else -> "STRAIGHT"
        }
        val distance = Regex("(?i)\\b(\\d+(?:[.,]\\d+)?)\\s*(m|meter|meters|km|kilometer|kilometers|mi|mile|miles)\\b").find(raw)?.let {
            val n = it.groupValues[1].replace(',', '.')
            val u = it.groupValues[2].lowercase(Locale.US)
            when { u.startsWith("km") || u.startsWith("kilometer") -> "$n km"; u.startsWith("mi") || u.startsWith("mile") -> "$n mi"; else -> "$n m" }
        } ?: "--"
        val next = when {
            Regex("(?i)\\bnext\\s+(left|right)\\b").find(raw)?.groupValues?.get(1)?.equals("left", true) == true -> "LEFT"
            Regex("(?i)\\bnext\\s+(left|right)\\b").find(raw)?.groupValues?.get(1)?.equals("right", true) == true -> "RIGHT"
            else -> "STRAIGHT"
        }
        return NavData(main, distance, next, raw)
    }
}
